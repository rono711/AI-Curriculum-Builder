<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * English language strings.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

//
// Plugin
//

$string['pluginname'] = 'Rono Curriculum Builder';
$string['pluginadministration'] = 'Rono Curriculum Builder';
$string['privacy:metadata'] = 'The Rono Curriculum Builder plugin stores lesson publishing information.';

//
// Settings
//

$string['settings'] = 'Settings';
$string['generalsettings'] = 'General Settings';
$string['apisettings'] = 'API Settings';
$string['publishsettings'] = 'Publishing Settings';
$string['loggingsettings'] = 'Logging Settings';
$string['securitysettings'] = 'Security Settings';

$string['enableplugin'] = 'Enable plugin';
$string['enableplugin_desc'] = 'Enable or disable the Rono Curriculum Builder plugin.';

$string['enablelogging'] = 'Enable logging';
$string['enablelogging_desc'] = 'Enable detailed logging for lesson publishing.';

$string['debugmode'] = 'Debug mode';
$string['debugmode_desc'] = 'Enable debug logging for development purposes.';

$string['defaultcoursecategory'] = 'Default Course Category';
$string['defaultcoursecategory_desc'] = 'Default Moodle course category used when creating new courses.';

//
// External Service
//

$string['servicename'] = 'Rono Curriculum Builder';
$string['serviceshortname'] = 'local_rono_Curriculum_Builder';

//
// Capabilities
//

$string['rono_curriculumbuilder:publishlesson'] = 'Publish lessons';
$string['rono_curriculumbuilder:updatelesson'] = 'Update lessons';
$string['rono_curriculumbuilder:deletelesson'] = 'Delete lessons';
$string['rono_curriculumbuilder:viewlogs'] = 'View publishing logs';
$string['rono_curriculumbuilder:manage'] = 'Manage Rono Curriculum Builder';

//
// API
//

$string['publishlesson'] = 'Publish Lesson';
$string['updatelesson'] = 'Update Lesson';
$string['deletelesson'] = 'Delete Lesson';
$string['publishresource'] = 'Publish Resource';
$string['publishquiz'] = 'Publish Quiz';
$string['synclesson'] = 'Synchronise Lesson';
$string['ping'] = 'Ping';
$string['health'] = 'Health Check';

//
// Messages
//

$string['publishsuccess'] = 'Lesson published successfully.';
$string['updatesuccess'] = 'Lesson updated successfully.';
$string['deletesuccess'] = 'Lesson deleted successfully.';

$string['invalidpayload'] = 'Invalid publish payload.';
$string['invalidcourse'] = 'Invalid Moodle course.';
$string['invalidsection'] = 'Invalid Moodle section.';
$string['invalidlesson'] = 'Invalid lesson.';
$string['lessonnotfound'] = 'Lesson not found.';
$string['publishfailed'] = 'Lesson publishing failed.';
$string['permissiondenied'] = 'Permission denied.';
$string['serviceunavailable'] = 'Service unavailable.';

//
// Status
//

$string['statusdraft'] = 'Draft';
$string['statusqueued'] = 'Queued';
$string['statusvalidating'] = 'Validating';
$string['statuspublishing'] = 'Publishing';
$string['statuspublished'] = 'Published';
$string['statusupdating'] = 'Updating';
$string['statusupdated'] = 'Updated';
$string['statusarchived'] = 'Archived';
$string['statusdeleted'] = 'Deleted';
$string['statusfailed'] = 'Failed';

//
// Asset Types
//

$string['assetpptx'] = 'PowerPoint';
$string['assetgoogleslides'] = 'Google Slides';
$string['assetworksheet'] = 'Worksheet';
$string['assetteacherguide'] = 'Teacher Guide';
$string['assetquiz'] = 'Quiz';
$string['assethomework'] = 'Homework';
$string['assetnotebooklm'] = 'NotebookLM';
$string['assetpdf'] = 'PDF';
$string['assetthumbnail'] = 'Thumbnail';

//
// Integration Types
//

$string['integrationgoogledrive'] = 'Google Drive';
$string['integrationgoogleslides'] = 'Google Slides';
$string['integrationgamma'] = 'Gamma';
$string['integrationnotebooklm'] = 'NotebookLM';
$string['integrationn8n'] = 'n8n';

//
// Logging
//

$string['logpublishstarted'] = 'Lesson publishing started.';
$string['logpublishcompleted'] = 'Lesson publishing completed.';
$string['logpublishfailed'] = 'Lesson publishing failed.';
$string['logsyncstarted'] = 'Lesson synchronisation started.';
$string['logsynccompleted'] = 'Lesson synchronisation completed.';
$string['logsyncfailed'] = 'Lesson synchronisation failed.';