<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * External services definition.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * External functions.
 */
$functions = [

    'local_rono_publish_lesson' => [
        'classname'   => 'local_rono_curriculumbuilder\external\publish_lesson',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Publish a lesson into Moodle.',
        'type'        => 'write',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_update_lesson' => [
        'classname'   => 'local_rono_curriculumbuilder\external\update_lesson',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Update an existing Moodle lesson.',
        'type'        => 'write',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_delete_lesson' => [
        'classname'   => 'local_rono_curriculumbuilder\external\delete_lesson',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Delete a published Moodle lesson.',
        'type'        => 'write',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_sync_lesson' => [
        'classname'   => 'local_rono_curriculumbuilder\external\sync_lesson',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Synchronise lesson metadata.',
        'type'        => 'write',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_publish_quiz' => [
        'classname'   => 'local_rono_curriculumbuilder\external\publish_quiz',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Publish a Moodle quiz.',
        'type'        => 'write',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_publish_resource' => [
        'classname'   => 'local_rono_curriculumbuilder\external\publish_resource',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Publish a Moodle resource.',
        'type'        => 'write',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_ping' => [
        'classname'   => 'local_rono_curriculumbuilder\external\ping',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'API connectivity test.',
        'type'        => 'read',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],

    'local_rono_health' => [
        'classname'   => 'local_rono_curriculumbuilder\external\health',
        'methodname'  => 'execute',
        'classpath'   => '',
        'description' => 'Health check endpoint.',
        'type'        => 'read',
        'ajax'        => false,
        'services'    => [
            'Rono Curriculum Builder',
        ],
    ],
];

/**
 * External services.
 */
$services = [

    'Rono Curriculum Builder' => [

        'functions' => [

            'local_rono_publish_lesson',
            'local_rono_update_lesson',
            'local_rono_delete_lesson',
            'local_rono_sync_lesson',
            'local_rono_publish_quiz',
            'local_rono_publish_resource',
            'local_rono_ping',
            'local_rono_health',

        ],

        'restrictedusers' => 0,

        'enabled' => 1,

        'shortname' => 'local_rono_Curriculum_Builder',

        'downloadfiles' => 1,

        'uploadfiles' => 1,

    ],

];