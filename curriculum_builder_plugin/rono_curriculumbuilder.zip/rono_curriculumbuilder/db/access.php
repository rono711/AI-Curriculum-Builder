<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Capability definitions.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = [

    /*
     * Publish lessons into Moodle.
     */
    'local/rono_curriculumbuilder:publishlesson' => [
        'riskbitmask' => RISK_CONFIG,

        'captype' => 'write',

        'contextlevel' => CONTEXT_SYSTEM,

        'archetypes' => [
            'manager' => CAP_ALLOW,
        ],
    ],

    /*
     * Update previously published lessons.
     */
    'local/rono_curriculumbuilder:updatelesson' => [
        'riskbitmask' => RISK_CONFIG,

        'captype' => 'write',

        'contextlevel' => CONTEXT_SYSTEM,

        'archetypes' => [
            'manager' => CAP_ALLOW,
        ],
    ],

    /*
     * Delete published lessons.
     */
    'local/rono_curriculumbuilder:deletelesson' => [
        'riskbitmask' => RISK_CONFIG,

        'captype' => 'write',

        'contextlevel' => CONTEXT_SYSTEM,

        'archetypes' => [
            'manager' => CAP_ALLOW,
        ],
    ],

    /*
     * View publishing history and logs.
     */
    'local/rono_curriculumbuilder:viewlogs' => [
        'riskbitmask' => RISK_PERSONAL,

        'captype' => 'read',

        'contextlevel' => CONTEXT_SYSTEM,

        'archetypes' => [
            'manager' => CAP_ALLOW,
        ],
    ],

    /*
     * Manage plugin configuration.
     */
    'local/rono_curriculumbuilder:manage' => [
        'riskbitmask' => RISK_CONFIG,

        'captype' => 'write',

        'contextlevel' => CONTEXT_SYSTEM,

        'archetypes' => [
            'manager' => CAP_ALLOW,
        ],
    ],

];