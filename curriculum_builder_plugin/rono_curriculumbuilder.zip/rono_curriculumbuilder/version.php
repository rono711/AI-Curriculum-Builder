<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Version information.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Plugin version.
 *
 * Version format:
 * YYYYMMDDXX
 *
 * Example:
 * 2026070500
 *
 * Increment XX for every release on the same day.
 */

$plugin->component = 'local_rono_curriculumbuilder';

$plugin->version = 2026070500;

$plugin->requires = 2025041400;

$plugin->release = '1.0.0';

$plugin->maturity = MATURITY_ALPHA;

$plugin->supported = [500, 599];

$plugin->dependencies = [];