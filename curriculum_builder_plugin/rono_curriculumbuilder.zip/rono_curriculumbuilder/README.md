# Rono Curriculum Builder

**Plugin Type:** Local Plugin

**Component:**

```
local_rono_curriculumbuilder
```

**Version**

```
2.0.0
```

**Author**

Mohammad Hassan

---

# Purpose

The Rono Curriculum Builder plugin provides a dedicated publishing API for the
AI Curriculum Builder Platform.

Instead of relying on Moodle's standard Web Services, the platform communicates
with this plugin to publish complete lessons.

---

# Architecture

```
Workbook
      │
      ▼
Prompt Generator
      │
      ▼
Gamma Presentation
      │
      ▼
Google Drive
      │
      ▼
Google Slides
      │
      ▼
HTML Page Builder
      │
      ▼
Python Publisher
      │
      ▼
Rono Curriculum Builder Plugin
      │
      ▼
Moodle
```

---

# Current Features

Version 2.0.0

- Plugin framework
- Ping endpoint
- Health endpoint
- Create Moodle Page
- Update Moodle Page
- Publish lesson endpoint
- Publisher class
- Page manager
- Metadata manager

---

# Plugin Structure

```
local/
└── rono_curriculumbuilder/
    │
    ├── version.php
    ├── index.php
    ├── lib.php
    ├── settings.php
    │
    ├── db/
    │     ├── access.php
    │     └── services.php
    │
    ├── classes/
    │     ├── page_manager.php
    │     ├── publisher.php
    │     ├── metadata_manager.php
    │     │
    │     └── external/
    │            ping.php
    │            health.php
    │            create_page.php
    │            update_page.php
    │            publish_lesson.php
    │
    ├── lang/
    │     └── en/
    │           local_rono_curriculumbuilder.php
    │
    └── README.md
```

---

# Installation

Copy the plugin to

```
public/local/rono_curriculumbuilder
```

Upgrade Moodle

```
php admin/cli/purge_caches.php

php admin/cli/upgrade.php
```

---

# Web Service

Plugin service

```
Rono Curriculum Builder
```

Functions

```
local_rono_curriculumbuilder_ping

local_rono_curriculumbuilder_health

local_rono_curriculumbuilder_create_page

local_rono_curriculumbuilder_update_page

local_rono_curriculumbuilder_publish_lesson
```

---

# Publishing Workflow

```
Workbook

↓

Prompt

↓

Gamma

↓

Google Drive

↓

Google Slides

↓

Page Builder

↓

Publisher

↓

Plugin

↓

Moodle
```

---

# Planned Version 2.1

- Google Slides embedding
- Resource upload
- Automatic update detection
- Lesson versioning

---

# Planned Version 2.2

- Metadata database
- Publishing history
- Rollback
- Analytics

---

# License

Internal software.

Copyright © Mohammad Hassan