<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publish Quiz Web Service.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use context_system;
use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;

/**
 * Publish Quiz External API.
 */
class publish_quiz extends external_api {

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {

        return new external_function_parameters([
            'payload' => new external_value(
                PARAM_RAW,
                'Quiz payload as JSON'
            ),
        ]);
    }

    /**
     * Execute.
     *
     * Placeholder for Version 1.1.
     *
     * @param string $payload
     * @return array
     */
    public static function execute(string $payload): array {

        self::validate_parameters(
            self::execute_parameters(),
            [
                'payload' => $payload
            ]
        );

        self::validate_context(
            context_system::instance()
        );

        require_capability(
            'local/rono_curriculumbuilder:publishlesson',
            context_system::instance()
        );

        return [
            'success' => false,
            'message' => 'Publish quiz is not implemented in Version 1.0.'
        ];
    }

    /**
     * Returns.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {

        return new external_single_structure([

            'success' => new external_value(
                PARAM_BOOL,
                'Success'
            ),

            'message' => new external_value(
                PARAM_TEXT,
                'Result message'
            ),

        ]);
    }
}