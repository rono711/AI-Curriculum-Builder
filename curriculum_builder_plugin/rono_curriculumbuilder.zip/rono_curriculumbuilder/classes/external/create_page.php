<?php
namespace local_rono_curriculumbuilder\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/lib/externallib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/mod/page/lib.php');

use context_course;
use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;
use required_capability_exception;

/**
 * ============================================================================
 * Rono Curriculum Builder
 *
 * Plugin:
 *     local_rono_curriculumbuilder
 *
 * File:
 *     classes/external/create_page.php
 *
 * Version:
 *     2.0.0
 *
 * Author:
 *     Mohammad Hassan
 *
 * Purpose:
 *     Create a Moodle Page activity.
 *
 * ============================================================================
 */
class create_page extends external_api {

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {

        return new external_function_parameters([

            'courseid' => new external_value(
                PARAM_INT,
                'Course ID'
            ),

            'section' => new external_value(
                PARAM_INT,
                'Course section number'
            ),

            'title' => new external_value(
                PARAM_TEXT,
                'Page title'
            ),

            'content' => new external_value(
                PARAM_RAW,
                'HTML content'
            ),

        ]);

    }

    /**
     * Execute.
     *
     * @return array
     */
    public static function execute(
        int $courseid,
        int $section,
        string $title,
        string $content
    ): array {

        global $DB;

        self::validate_parameters(
            self::execute_parameters(),
            [
                'courseid' => $courseid,
                'section'  => $section,
                'title'    => $title,
                'content'  => $content,
            ]
        );

        $course = $DB->get_record(
            'course',
            ['id' => $courseid],
            '*',
            MUST_EXIST
        );

        $context = context_course::instance($courseid);

        self::validate_context($context);

        require_capability(
            'local/rono_curriculumbuilder:publish',
            $context
        );

        $module = $DB->get_record(
            'modules',
            ['name' => 'page'],
            '*',
            MUST_EXIST
        );

        $page = new \stdClass();

        $page->course = $courseid;
        $page->name = $title;
        $page->intro = '';
        $page->introformat = FORMAT_HTML;
        $page->content = $content;
        $page->contentformat = FORMAT_HTML;
        $page->display = PAGE_DISPLAY_EMBED;
        $page->displayoptions = 'a:0:{}';
        $page->timemodified = time();

        $page->id = $DB->insert_record(
            'page',
            $page
        );

        $cm = new \stdClass();

        $cm->course = $courseid;
        $cm->module = $module->id;
        $cm->instance = $page->id;
        $cm->section = $section;
        $cm->visible = 1;
        $cm->groupmode = 0;
        $cm->groupingid = 0;
        $cm->completion = 0;

        $cmid = add_course_module($cm);

        course_add_cm_to_section(
            $courseid,
            $cmid,
            $section
        );

        rebuild_course_cache(
            $courseid,
            true
        );

        return [

            'status' => 'OK',

            'pageid' => $page->id,

            'cmid' => $cmid,

            'url' => (new \moodle_url(
                '/mod/page/view.php',
                ['id' => $cmid]
            ))->out(false),

        ];

    }

    /**
     * Return values.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {

        return new external_single_structure([

            'status' => new external_value(
                PARAM_TEXT,
                'Status'
            ),

            'pageid' => new external_value(
                PARAM_INT,
                'Page instance ID'
            ),

            'cmid' => new external_value(
                PARAM_INT,
                'Course module ID'
            ),

            'url' => new external_value(
                PARAM_URL,
                'Activity URL'
            ),

        ]);

    }

}