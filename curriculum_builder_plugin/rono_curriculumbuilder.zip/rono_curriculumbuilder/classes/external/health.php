<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Health Check Web Service.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use context_system;
use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;

/**
 * Health Check External API.
 */
class health extends external_api {

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {

        return new external_function_parameters([]);
    }

    /**
     * Execute.
     *
     * @return array
     */
    public static function execute(): array {

        global $DB;

        self::validate_context(
            context_system::instance()
        );

        $databaseok = true;

        try {

            $DB->count_records('course');

        } catch (\Throwable $exception) {

            $databaseok = false;
        }

        return [

            'success' => true,

            'plugin' => 'Rono Curriculum Builder',

            'version' => local_rono_curriculumbuilder_get_version(),

            'database' => $databaseok,

            'enabled' => local_rono_curriculumbuilder_is_enabled(),

            'logging' => local_rono_curriculumbuilder_logging_enabled(),

            'debug' => local_rono_curriculumbuilder_debug_enabled(),

            'status' => $databaseok ? 'Healthy' : 'Database Error',

            'timestamp' => time(),

        ];
    }

    /**
     * Returns.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {

        return new external_single_structure([

            'success' => new external_value(
                PARAM_BOOL,
                'Success'
            ),

            'plugin' => new external_value(
                PARAM_TEXT,
                'Plugin name'
            ),

            'version' => new external_value(
                PARAM_TEXT,
                'Plugin version'
            ),

            'database' => new external_value(
                PARAM_BOOL,
                'Database connectivity'
            ),

            'enabled' => new external_value(
                PARAM_BOOL,
                'Plugin enabled'
            ),

            'logging' => new external_value(
                PARAM_BOOL,
                'Logging enabled'
            ),

            'debug' => new external_value(
                PARAM_BOOL,
                'Debug mode enabled'
            ),

            'status' => new external_value(
                PARAM_TEXT,
                'Overall health status'
            ),

            'timestamp' => new external_value(
                PARAM_INT,
                'Unix timestamp'
            ),

        ]);
    }
}