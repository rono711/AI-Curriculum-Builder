<?php
namespace local_rono_curriculumbuilder\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/lib/externallib.php');

use context_module;
use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;

/**
 * ============================================================================
 * Rono Curriculum Builder
 *
 * Plugin:
 *     local_rono_curriculumbuilder
 *
 * File:
 *     classes/external/update_page.php
 *
 * Version:
 *     2.0.0
 *
 * Author:
 *     Mohammad Hassan
 *
 * Purpose:
 *     Update an existing Moodle Page activity.
 *
 * ============================================================================
 */
class update_page extends external_api {

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {

        return new external_function_parameters([

            'pageid' => new external_value(
                PARAM_INT,
                'Page instance ID'
            ),

            'title' => new external_value(
                PARAM_TEXT,
                'Page title'
            ),

            'content' => new external_value(
                PARAM_RAW,
                'HTML content'
            ),

        ]);

    }

    /**
     * Execute.
     *
     * @return array
     */
    public static function execute(
        int $pageid,
        string $title,
        string $content
    ): array {

        global $DB;

        self::validate_parameters(
            self::execute_parameters(),
            [
                'pageid' => $pageid,
                'title' => $title,
                'content' => $content,
            ]
        );

        $page = $DB->get_record(
            'page',
            [
                'id' => $pageid
            ],
            '*',
            MUST_EXIST
        );

        $cm = get_coursemodule_from_instance(
            'page',
            $pageid,
            $page->course,
            false,
            MUST_EXIST
        );

        $context = context_module::instance(
            $cm->id
        );

        self::validate_context(
            $context
        );

        require_capability(
            'local/rono_curriculumbuilder:publish',
            $context
        );

        $page->name = $title;

        $page->content = $content;

        $
		
		        $page->timemodified = time();

        $DB->update_record(
            'page',
            $page
        );

        rebuild_course_cache(
            $page->course,
            true
        );

        return [

            'status' => 'OK',

            'pageid' => $page->id,

            'cmid' => $cm->id,

            'url' => (new \moodle_url(
                '/mod/page/view.php',
                [
                    'id' => $cm->id
                ]
            ))->out(false),

        ];

    }

    /**
     * Return values.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {

        return new external_single_structure([

            'status' => new external_value(

                PARAM_TEXT,

                'Status'

            ),

            'pageid' => new external_value(

                PARAM_INT,

                'Page Instance ID'

            ),

            'cmid' => new external_value(

                PARAM_INT,

                'Course Module ID'

            ),

            'url' => new external_value(

                PARAM_URL,

                'Activity URL'

            ),

        ]);

    }

}