<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publish Lesson Web Service.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\external;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/externallib.php');

use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;
use local_rono_curriculumbuilder\domain\publish_request;
use local_rono_curriculumbuilder\service\publisher_service;

/**
 * Publish Lesson External API.
 */
class publish_lesson extends external_api {

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {

        return new external_function_parameters([

            'payload' => new external_value(
                PARAM_RAW,
                'Lesson publish payload as JSON'
            ),

        ]);
    }

    /**
     * Execute.
     *
     * @param string $payload
     * @return array
     */
    public static function execute(
        string $payload
    ): array {

        self::validate_parameters(
            self::execute_parameters(),
            [
                'payload' => $payload
            ]
        );

        $context = \context_system::instance();

        self::validate_context($context);

        require_capability(
            'local/rono_curriculumbuilder:publishlesson',
            $context
        );

        $data = json_decode(
            $payload,
            true,
            512,
            JSON_THROW_ON_ERROR
        );

        $request = new publish_request($data);

        $publisher = new publisher_service();

        $result = $publisher->publish($request);

        return $result->to_array();
    }

    /**
     * Return definition.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {

        return new external_single_structure([

            'success' => new external_value(
                PARAM_BOOL,
                'Success'
            ),

            'message' => new external_value(
                PARAM_TEXT,
                'Result message'
            ),

            'courseid' => new external_value(
                PARAM_INT,
                'Course ID'
            ),

            'sectionid' => new external_value(
                PARAM_INT,
                'Section ID'
            ),

            'cmid' => new external_value(
                PARAM_INT,
                'Course Module ID'
            ),

            'pageid' => new external_value(
                PARAM_INT,
                'Page ID'
            ),

            'activity_url' => new external_value(
                PARAM_URL,
                'Moodle Activity URL'
            ),

            'lesson_uuid' => new external_value(
                PARAM_TEXT,
                'Lesson UUID'
            ),

            'build_id' => new external_value(
                PARAM_TEXT,
                'Build ID'
            ),

            'publication_status' => new external_value(
                PARAM_TEXT,
                'Publication Status'
            ),

        ]);
    }
}