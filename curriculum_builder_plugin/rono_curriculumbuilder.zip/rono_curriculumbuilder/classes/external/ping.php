<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Ping Web Service.
 *
 * Simple connectivity test for the Rono Curriculum Builder API.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use context_system;
use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;

/**
 * Ping External API.
 */
class ping extends external_api {

    /**
     * Parameters.
     *
     * @return external_function_parameters
     */
    public static function execute_parameters(): external_function_parameters {

        return new external_function_parameters([]);
    }

    /**
     * Execute.
     *
     * @return array
     */
    public static function execute(): array {

        self::validate_context(
            context_system::instance()
        );

        return [
            'success' => true,
            'plugin' => 'Rono Curriculum Builder',
            'version' => local_rono_curriculumbuilder_get_version(),
            'status' => 'OK',
            'timestamp' => time(),
        ];
    }

    /**
     * Returns.
     *
     * @return external_single_structure
     */
    public static function execute_returns(): external_single_structure {

        return new external_single_structure([

            'success' => new external_value(
                PARAM_BOOL,
                'Success'
            ),

            'plugin' => new external_value(
                PARAM_TEXT,
                'Plugin name'
            ),

            'version' => new external_value(
                PARAM_TEXT,
                'Plugin version'
            ),

            'status' => new external_value(
                PARAM_TEXT,
                'API status'
            ),

            'timestamp' => new external_value(
                PARAM_INT,
                'Unix timestamp'
            ),

        ]);
    }
}