<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Resource Service.
 *
 * Handles lesson resources and assets.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\repository\lesson_asset_repository;

/**
 * Resource service.
 */
class resource_service {

    /**
     * Asset repository.
     *
     * @var lesson_asset_repository
     */
    private lesson_asset_repository $repository;

    /**
     * Constructor.
     */
    public function __construct() {

        $this->repository = new lesson_asset_repository();
    }

    /**
     * Save lesson resources.
     *
     * @param int $lessonid
     * @param array $resources
     * @return void
     * @throws \dml_exception
     */
    public function save_resources(
        int $lessonid,
        array $resources
    ): void {

        foreach ($resources as $resource) {

            $record = new \stdClass();

            $record->lessonid = $lessonid;
            $record->lesson_uuid = $resource['lesson_uuid'] ?? '';
            $record->build_id = $resource['build_id'] ?? '';

            $record->asset_uuid = $resource['asset_uuid'] ?? uniqid('asset_');

            $record->asset_type = $resource['type'] ?? 'resource';

            $record->asset_name = $resource['name'] ?? '';

            $record->display_name = $resource['display_name'] ?? '';

            $record->generator = $resource['generator'] ?? '';

            $record->generator_version = $resource['generator_version'] ?? '';

            $record->filename = $resource['filename'] ?? '';

            $record->file_extension = $resource['extension'] ?? '';

            $record->mime_type = $resource['mime_type'] ?? '';

            $record->file_size = $resource['file_size'] ?? 0;

            $record->stored_file_id = 0;

            $record->contextid = 0;

            $record->google_drive_file_id =
                $resource['google_drive_file_id'] ?? '';

            $record->google_slides_id =
                $resource['google_slides_id'] ?? '';

            $record->notebooklm_id =
                $resource['notebooklm_id'] ?? '';

            $record->url = $resource['url'] ?? '';

            $record->embed_url = $resource['embed_url'] ?? '';

            $record->download_url = $resource['download_url'] ?? '';

            $record->asset_status = 'available';

            $record->sort_order = $resource['sort_order'] ?? 0;

            $record->timecreated = time();

            $record->timemodified = time();

            $this->repository->create($record);
        }
    }

    /**
     * Returns all resources for a lesson.
     *
     * @param int $lessonid
     * @return array
     * @throws \dml_exception
     */
    public function get_resources(
        int $lessonid
    ): array {

        return $this->repository->find_by_lesson(
            $lessonid
        );
    }

    /**
     * Returns resources by asset type.
     *
     * @param int $lessonid
     * @param string $type
     * @return array
     * @throws \dml_exception
     */
    public function get_resources_by_type(
        int $lessonid,
        string $type
    ): array {

        return $this->repository->find_by_type(
            $lessonid,
            $type
        );
    }

    /**
     * Deletes all lesson resources.
     *
     * @param int $lessonid
     * @return void
     * @throws \dml_exception
     */
    public function delete_resources(
        int $lessonid
    ): void {

        $this->repository->delete_by_lesson(
            $lessonid
        );
    }

    /**
     * Returns the total number of resources.
     *
     * @param int $lessonid
     * @return int
     * @throws \dml_exception
     */
    public function count_resources(
        int $lessonid
    ): int {

        return $this->repository->count(
            $lessonid
        );
    }

    /**
     * Determines whether a lesson contains resources.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function has_resources(
        int $lessonid
    ): bool {

        return $this->count_resources(
            $lessonid
        ) > 0;
    }
}