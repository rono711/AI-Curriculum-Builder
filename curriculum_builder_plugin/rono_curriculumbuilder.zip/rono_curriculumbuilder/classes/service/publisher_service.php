<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publisher Service.
 *
 * Main orchestration service responsible for publishing lessons into Moodle.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\domain\lesson;
use local_rono_curriculumbuilder\domain\page;
use local_rono_curriculumbuilder\domain\publish_request;
use local_rono_curriculumbuilder\domain\publish_result;
use local_rono_curriculumbuilder\repository\lesson_repository;
use local_rono_curriculumbuilder\repository\publish_payload_repository;

/**
 * Lesson Publisher.
 */
class publisher_service {

    /** @var validation_service */
    private validation_service $validation;

    /** @var course_service */
    private course_service $course;

    /** @var section_service */
    private section_service $section;

    /** @var page_service */
    private page_service $page;

    /** @var resource_service */
    private resource_service $resource;

    /** @var metadata_service */
    private metadata_service $metadata;

    /** @var logger_service */
    private logger_service $logger;

    /** @var lesson_repository */
    private lesson_repository $lessonrepository;

    /** @var publish_payload_repository */
    private publish_payload_repository $payloadrepository;

    /**
     * Constructor.
     */
    public function __construct() {

        $this->validation = new validation_service();
        $this->course = new course_service();
        $this->section = new section_service();
        $this->page = new page_service();
        $this->resource = new resource_service();
        $this->metadata = new metadata_service();
        $this->logger = new logger_service();

        $this->lessonrepository = new lesson_repository();
        $this->payloadrepository = new publish_payload_repository();
    }

    /**
     * Publish a lesson.
     *
     * @param publish_request $request
     * @return publish_result
     * @throws \Throwable
     */
    public function publish(
        publish_request $request
    ): publish_result {

        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();

        try {

            /*
             * -----------------------------------------------------------------
             * Validate
             * -----------------------------------------------------------------
             */

            $this->validation->validate_publish_request($request);

            /*
             * -----------------------------------------------------------------
             * Course
             * -----------------------------------------------------------------
             */

            $this->course->require_login(
                $request->get_course_id()
            );

            $this->course->require_update_capability(
                $request->get_course_id()
            );

            /*
             * -----------------------------------------------------------------
             * Section
             * -----------------------------------------------------------------
             */

            $section = $this->section->get_or_create_section(
                $request->get_course_id(),
                $request->get_section_id()
            );

            /*
             * -----------------------------------------------------------------
             * Page
             * -----------------------------------------------------------------
             */

            $page = new page([

                'courseid' => $request->get_course_id(),

                'sectionid' => $section->get_section_number(),

                'name' => $request->get_lesson_title(),

                'intro' => '',

                'content' => $this->page->build_content(
                    $request->get_html(),
                    $request->get_google_slides_embed()
                ),

                'visible' => true,

            ]);

            $cmid = $this->page->create($page);

            /*
             * -----------------------------------------------------------------
             * Lesson Record
             * -----------------------------------------------------------------
             */

            $lesson = new lesson([

                'lessonuuid' => uniqid('lesson_'),

                'buildid' => $request->get_build_id(),

                'lessonpackageid' => $request->get_lesson_package_id(),

                'topicid' => $request->get_topic_id(),

                'curriculumcode' => $request->get_curriculum_code(),

                'lessontitle' => $request->get_lesson_title(),

                'courseid' => $request->get_course_id(),

                'sectionid' => $section->get_id(),

                'cmid' => $cmid,

                'activityurl' => $this->page->activity_url($cmid),

                'publishversion' => 1,

                'publicationstatus' => 'published',

                'payloadhash' => hash(
                    'sha256',
                    $request->to_json()
                ),

                'publishedat' => time(),
                'createdby' => $USER->id,

                'modifiedby' => $USER->id,

                'timecreated' => time(),

                'timemodified' => time(),

            ]);

            $lessonid = $this->lessonrepository->create($lesson);

            /*
             * -----------------------------------------------------------------
             * Payload Snapshot
             * -----------------------------------------------------------------
             */

            $payload = new \stdClass();

            $payload->lessonid = $lessonid;
            $payload->build_id = $request->get_build_id();
            $payload->lesson_uuid = $lesson->get_lesson_uuid();
            $payload->publish_version = 1;
            $payload->payload_format_version = '1.0.0';
            $payload->payload_json = $request->to_json();
            $payload->payload_hash = hash('sha256', $request->to_json());
            $payload->published_by = $USER->id;
            $payload->publish_status = 'published';
            $payload->timecreated = time();

            $this->payloadrepository->create($payload);

            /*
             * -----------------------------------------------------------------
             * Curriculum Metadata
             * -----------------------------------------------------------------
             */

            $this->metadata->save(
                $lessonid,
                $request->get_metadata()
            );

            /*
             * -----------------------------------------------------------------
             * Resources
             * -----------------------------------------------------------------
             */

            if ($request->has_resources()) {

                $this->resource->save_resources(
                    $lessonid,
                    $request->get_resources()
                );
            }

            /*
             * -----------------------------------------------------------------
             * Logging
             * -----------------------------------------------------------------
             */

            $this->logger->success(
                $lessonid,
                $lesson->get_lesson_uuid(),
                $request->get_build_id(),
                'publish',
                'Lesson published successfully.'
            );

            $transaction->allow_commit();

        return new publish_result([

           'success' => true,

           'message' => 'Lesson published successfully.',

           'courseid' => $request->get_course_id(),

           'sectionid' => $section->get_id(),

           'cmid' => $cmid,

           'activity_url' => $this->page->activity_url($cmid),

           'lesson_uuid' => $lesson->get_lesson_uuid(),

           'build_id' => $request->get_build_id(),

           'publication_status' => 'published',

        ]);


        } catch (\Throwable $exception) {

            $transaction->rollback($exception);

            throw $exception;
        }
    }
}