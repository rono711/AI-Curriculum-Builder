<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Logger Service.
 *
 * Handles lesson publishing history.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\repository\publish_history_repository;

/**
 * Logger service.
 */
class logger_service {

    /**
     * Publish history repository.
     *
     * @var publish_history_repository
     */
    private publish_history_repository $repository;

    /**
     * Constructor.
     */
    public function __construct() {

        $this->repository = new publish_history_repository();
    }

    /**
     * Write a history entry.
     *
     * @param int $lessonid
     * @param string $lessonuuid
     * @param string $buildid
     * @param string $eventtype
     * @param string $status
     * @param string $message
     * @param array $details
     * @param int $durationms
     * @return int
     * @throws \dml_exception
     */
    public function log(
        int $lessonid,
        string $lessonuuid,
        string $buildid,
        string $eventtype,
        string $status,
        string $message = '',
        array $details = [],
        int $durationms = 0
    ): int {

        global $USER;

        $record = new \stdClass();

        $record->lessonid = $lessonid;
        $record->lesson_uuid = $lessonuuid;
        $record->build_id = $buildid;

        $record->event_type = $eventtype;
        $record->event_status = $status;
        $record->event_source = 'Rono Curriculum Builder';

        $record->publish_version = 1;

        $record->message = $message;

        $record->details_json = json_encode(
            $details,
            JSON_UNESCAPED_UNICODE
        );

        $record->duration_ms = $durationms;

        $record->userid = $USER->id ?? 0;

        $record->request_id = uniqid('req_');

        $record->correlation_id = uniqid('corr_');

        $record->timecreated = time();

        return $this->repository->create($record);
    }

    /**
     * Log a successful operation.
     *
     * @param int $lessonid
     * @param string $lessonuuid
     * @param string $buildid
     * @param string $eventtype
     * @param string $message
     * @param array $details
     * @return int
     * @throws \dml_exception
     */
    public function success(
        int $lessonid,
        string $lessonuuid,
        string $buildid,
        string $eventtype,
        string $message = '',
        array $details = []
    ): int {

        return $this->log(
            $lessonid,
            $lessonuuid,
            $buildid,
            $eventtype,
            'success',
            $message,
            $details
        );
    }

    /**
     * Log a failed operation.
     *
     * @param int $lessonid
     * @param string $lessonuuid
     * @param string $buildid
     * @param string $eventtype
     * @param string $message
     * @param array $details
     * @return int
     * @throws \dml_exception
     */
    public function failure(
        int $lessonid,
        string $lessonuuid,
        string $buildid,
        string $eventtype,
        string $message = '',
        array $details = []
    ): int {

        return $this->log(
            $lessonid,
            $lessonuuid,
            $buildid,
            $eventtype,
            'failed',
            $message,
            $details
        );
    }

    /**
     * Returns lesson history.
     *
     * @param int $lessonid
     * @return array
     * @throws \dml_exception
     */
    public function history(int $lessonid): array {

        return $this->repository->find_by_lesson(
            $lessonid
        );
    }

    /**
     * Returns build history.
     *
     * @param string $buildid
     * @return array
     * @throws \dml_exception
     */
    public function build_history(string $buildid): array {

        return $this->repository->find_by_build(
            $buildid
        );
    }

    /**
     * Returns history by event.
     *
     * @param string $eventtype
     * @return array
     * @throws \dml_exception
     */
    public function event_history(string $eventtype): array {

        return $this->repository->find_by_event(
            $eventtype
        );
    }
}