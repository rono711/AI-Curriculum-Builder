<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Validation Service.
 *
 * Validates incoming publish requests before any Moodle changes occur.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use context_course;
use local_rono_curriculumbuilder\domain\publish_request;
use moodle_exception;

/**
 * Validation service.
 */
class validation_service {

    /**
     * Validate a publish request.
     *
     * @param publish_request $request
     * @throws moodle_exception
     */
    public function validate_publish_request(
        publish_request $request
    ): void {

        $this->validate_course(
            $request->get_course_id()
        );

        $this->validate_section(
            $request->get_section_id()
        );

        $this->validate_lesson_title(
            $request->get_lesson_title()
        );

        $this->validate_curriculum_code(
            $request->get_curriculum_code()
        );

        $this->validate_html(
            $request->get_html()
        );
    }

    /**
     * Validate the Moodle course.
     *
     * @param int $courseid
     * @throws moodle_exception
     */
    public function validate_course(
        int $courseid
    ): void {

        global $DB;

        if (!$courseid) {
            throw new moodle_exception(
                'invalidcourse',
                'local_rono_curriculumbuilder'
            );
        }

        if (!$DB->record_exists('course', ['id' => $courseid])) {
            throw new moodle_exception(
                'invalidcourse',
                'local_rono_curriculumbuilder'
            );
        }

        $context = context_course::instance($courseid);

        require_capability(
            'moodle/course:update',
            $context
        );
    }

    /**
     * Validate section number.
     *
     * @param int $sectionid
     * @throws moodle_exception
     */
    public function validate_section(
        int $sectionid
    ): void {

        if ($sectionid < 0) {
            throw new moodle_exception(
                'invalidsection',
                'local_rono_curriculumbuilder'
            );
        }
    }

    /**
     * Validate lesson title.
     *
     * @param string $title
     * @throws moodle_exception
     */
    public function validate_lesson_title(
        string $title
    ): void {

        if (trim($title) === '') {
            throw new moodle_exception(
                'invalidlesson',
                'local_rono_curriculumbuilder'
            );
        }

        if (\core_text::strlen($title) > 255) {
            throw new moodle_exception(
                'invalidlesson',
                'local_rono_curriculumbuilder'
            );
        }
    }

    /**
     * Validate curriculum code.
     *
     * @param string $code
     * @throws moodle_exception
     */
    public function validate_curriculum_code(
        string $code
    ): void {

        if (trim($code) === '') {
            throw new moodle_exception(
                'invalidpayload',
                'local_rono_curriculumbuilder'
            );
        }
    }

    /**
     * Validate lesson HTML.
     *
     * @param string $html
     * @throws moodle_exception
     */
    public function validate_html(
        string $html
    ): void {

        if (trim($html) === '') {
            throw new moodle_exception(
                'invalidpayload',
                'local_rono_curriculumbuilder'
            );
        }
    }

    /**
     * Validate uploaded resources.
     *
     * @param array $resources
     * @throws moodle_exception
     */
    public function validate_resources(
        array $resources
    ): void {

        foreach ($resources as $resource) {

            if (empty($resource['type'])) {
                throw new moodle_exception(
                    'invalidpayload',
                    'local_rono_curriculumbuilder'
                );
            }

            if (empty($resource['url'])) {
                throw new moodle_exception(
                    'invalidpayload',
                    'local_rono_curriculumbuilder'
                );
            }
        }
    }

    /**
     * Validate Google Slides embed.
     *
     * @param string $embed
     * @throws moodle_exception
     */
    public function validate_google_slides(
        string $embed
    ): void {

        if ($embed === '') {
            return;
        }

        if (stripos($embed, '<iframe') === false) {
            throw new moodle_exception(
                'invalidpayload',
                'local_rono_curriculumbuilder'
            );
        }
    }

    /**
     * Validate quiz payload.
     *
     * @param array $quiz
     * @throws moodle_exception
     */
    public function validate_quiz(
        array $quiz
    ): void {

        if (empty($quiz)) {
            return;
        }

        if (empty($quiz['title'])) {
            throw new moodle_exception(
                'invalidpayload',
                'local_rono_curriculumbuilder'
            );
        }
    }
}