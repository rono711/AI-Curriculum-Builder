<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Course Service.
 *
 * Handles Moodle course operations.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\domain\course;
use moodle_exception;

/**
 * Course service.
 */
class course_service {

    /**
     * Get a Moodle course.
     *
     * @param int $courseid
     * @return course
     * @throws moodle_exception
     */
    public function get_course(int $courseid): course {

        global $DB;

        $record = $DB->get_record(
            'course',
            [
                'id' => $courseid
            ]
        );

        if (!$record) {
            throw new moodle_exception(
                'invalidcourse',
                'local_rono_curriculumbuilder'
            );
        }

        return new course([
            'id' => $record->id,
            'fullname' => $record->fullname,
            'shortname' => $record->shortname,
            'categoryid' => $record->category,
            'visible' => (bool)$record->visible,
        ]);
    }

    /**
     * Course exists.
     *
     * @param int $courseid
     * @return bool
     */
    public function exists(int $courseid): bool {

        global $DB;

        return $DB->record_exists(
            'course',
            [
                'id' => $courseid
            ]
        );
    }

    /**
     * Ensure the user can update the course.
     *
     * @param int $courseid
     * @throws moodle_exception
     */
    public function require_update_capability(int $courseid): void {

        $context = \context_course::instance($courseid);

        require_capability(
            'moodle/course:update',
            $context
        );
    }

    /**
     * Returns the course context.
     *
     * @param int $courseid
     * @return \context_course
     */
    public function get_context(int $courseid): \context_course {

        return \context_course::instance($courseid);
    }

    /**
     * Returns whether the course is visible.
     *
     * @param int $courseid
     * @return bool
     * @throws moodle_exception
     */
    public function is_visible(int $courseid): bool {

        return $this->get_course($courseid)->is_visible();
    }

    /**
     * Returns the course format.
     *
     * @param int $courseid
     * @return string
     * @throws moodle_exception
     */
    public function get_format(int $courseid): string {

        $course = get_course($courseid);

        return $course->format;
    }

    /**
     * Require the user to be logged into the course.
     *
     * @param int $courseid
     */
    public function require_login(int $courseid): void {

        $course = get_course($courseid);

        require_login($course);
    }
}