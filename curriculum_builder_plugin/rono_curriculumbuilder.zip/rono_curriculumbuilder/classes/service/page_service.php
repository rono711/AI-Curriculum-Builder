<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Page Service.
 *
 * Handles Moodle Page activities.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\domain\page;
use moodle_exception;

/**
 * Page service.
 */
class page_service {

   /**
 * Creates a Moodle Page activity.
 *
 * @param page $page
 * @return int
 * @throws moodle_exception
 */
public function create(page $page): int {

    global $CFG, $DB;

    require_once($CFG->dirroot . '/course/modlib.php');
    require_once($CFG->dirroot . '/course/lib.php');

    $record = $page->to_record();

    $course = get_course($record->course);

    $module = $DB->get_record(
        'modules',
        [
            'name' => 'page'
        ],
        '*',
        MUST_EXIST
    );

    $data = new \stdClass();

    /*
     * Required by create_module()
     */

    $data->course = $course->id;

    $data->module = $module->id;

    $data->modulename = 'page';

    $data->section = $record->sectionid;

    $data->visible = 1;

    /*
     * Page fields
     */

    $data->name = $record->name;

    $data->introeditor = [
        'text' => $record->intro,
        'format' => FORMAT_HTML,
        'itemid' => 0,
    ];

    $data->content = $record->content;

    $data->contentformat = FORMAT_HTML;

    /*
     * Standard module defaults
     */

    $data->groupmode = 0;

    $data->groupingid = 0;

    $data->completion = 0;

    $data->completionview = 0;

    $data->availabilityconditionsjson = null;

    $data->showdescription = 0;

    $cm = create_module($data);

    return (int)$cm->coursemodule;
}

    /**
     * Returns a Moodle Page activity.
     *
     * @param int $pageid
     * @return page|null
     * @throws \dml_exception
     */
    public function get(int $pageid): ?page {

        global $DB;

        $record = $DB->get_record(
            'page',
            [
                'id' => $pageid
            ]
        );

        if (!$record) {
            return null;
        }

        return new page([
            'id' => $record->id,
            'courseid' => $record->course,
            'name' => $record->name,
            'intro' => $record->intro,
            'content' => $record->content,
        ]);
    }

    /**
     * Determines whether a page exists.
     *
     * @param int $pageid
     * @return bool
     * @throws \dml_exception
     */
    public function exists(int $pageid): bool {

        global $DB;

        return $DB->record_exists(
            'page',
            [
                'id' => $pageid
            ]
        );
    }

    /**
     * Deletes a Moodle Page activity.
     *
     * @param int $cmid
     * @return bool
     * @throws moodle_exception
     */
    public function delete(int $cmid): bool {

        global $CFG;

        require_once($CFG->dirroot . '/course/lib.php');

        return course_delete_module($cmid);
    }

    /**
     * Builds the lesson HTML.
     *
     * @param string $lessonhtml
     * @param string|null $googleembed
     * @return string
     */
    public function build_content(
        string $lessonhtml,
        ?string $googleembed = null
    ): string {

        $content = $lessonhtml;

        if (!empty($googleembed)) {

            $content .= PHP_EOL;
            $content .= '<hr>';
            $content .= PHP_EOL;
            $content .= $googleembed;
        }

        return $content;
    }

    /**
     * Generates the Moodle activity URL.
     *
     * @param int $cmid
     * @return string
     */
    public function activity_url(int $cmid): string {

        global $CFG;

        return $CFG->wwwroot . '/mod/page/view.php?id=' . $cmid;
    }
}