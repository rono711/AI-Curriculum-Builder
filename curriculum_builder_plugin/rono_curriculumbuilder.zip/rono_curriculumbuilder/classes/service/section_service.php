<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Section Service.
 *
 * Handles Moodle course section operations.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\domain\section;
use moodle_exception;

/**
 * Section service.
 */
class section_service {

    /**
     * Returns a course section.
     *
     * @param int $courseid
     * @param int $sectionnumber
     * @return section|null
     * @throws \dml_exception
     */
    public function get_section(
        int $courseid,
        int $sectionnumber
    ): ?section {

        global $DB;

        $record = $DB->get_record(
            'course_sections',
            [
                'course' => $courseid,
                'section' => $sectionnumber
            ]
        );

        if (!$record) {
            return null;
        }

        return new section([
            'id' => $record->id,
            'courseid' => $record->course,
            'section' => $record->section,
            'name' => $record->name ?? '',
            'visible' => (bool)$record->visible,
        ]);
    }

    /**
     * Determines whether a section exists.
     *
     * @param int $courseid
     * @param int $sectionnumber
     * @return bool
     * @throws \dml_exception
     */
    public function exists(
        int $courseid,
        int $sectionnumber
    ): bool {

        global $DB;

        return $DB->record_exists(
            'course_sections',
            [
                'course' => $courseid,
                'section' => $sectionnumber
            ]
        );
    }

    /**
     * Creates a course section if it does not already exist.
     *
     * @param int $courseid
     * @param int $sectionnumber
     * @return section
     * @throws moodle_exception
     */
    public function create_section(
        int $courseid,
        int $sectionnumber
    ): section {

        if ($this->exists($courseid, $sectionnumber)) {
            return $this->get_section($courseid, $sectionnumber);
        }

        require_once($GLOBALS['CFG']->dirroot . '/course/lib.php');

        $format = course_get_format($courseid);

        $format->create_section($sectionnumber);

        $section = $this->get_section($courseid, $sectionnumber);

        if (!$section) {
            throw new moodle_exception(
                'invalidsection',
                'local_rono_curriculumbuilder'
            );
        }

        return $section;
    }

    /**
     * Returns an existing section or creates it.
     *
     * @param int $courseid
     * @param int $sectionnumber
     * @return section
     * @throws moodle_exception
     */
    public function get_or_create_section(
        int $courseid,
        int $sectionnumber
    ): section {

        $section = $this->get_section(
            $courseid,
            $sectionnumber
        );

        if ($section) {
            return $section;
        }

        return $this->create_section(
            $courseid,
            $sectionnumber
        );
    }

    /**
     * Returns all sections in a course.
     *
     * @param int $courseid
     * @return section[]
     * @throws \dml_exception
     */
    public function get_sections(int $courseid): array {

        global $DB;

        $records = $DB->get_records(
            'course_sections',
            [
                'course' => $courseid
            ],
            'section ASC'
        );

        $sections = [];

        foreach ($records as $record) {

            $sections[] = new section([
                'id' => $record->id,
                'courseid' => $record->course,
                'section' => $record->section,
                'name' => $record->name ?? '',
                'visible' => (bool)$record->visible,
            ]);
        }

        return $sections;
    }

    /**
     * Returns the number of sections in a course.
     *
     * @param int $courseid
     * @return int
     * @throws \dml_exception
     */
    public function count_sections(int $courseid): int {

        global $DB;

        return $DB->count_records(
            'course_sections',
            [
                'course' => $courseid
            ]
        );
    }

    /**
     * Deletes an empty section.
     *
     * Note:
     * This method only deletes sections that contain no activities.
     *
     * @param int $courseid
     * @param int $sectionnumber
     * @return bool
     * @throws moodle_exception
     */
    public function delete_section(
        int $courseid,
        int $sectionnumber
    ): bool {

        require_once($GLOBALS['CFG']->dirroot . '/course/lib.php');

        $format = course_get_format($courseid);

        return $format->delete_section($sectionnumber, true);
    }
}