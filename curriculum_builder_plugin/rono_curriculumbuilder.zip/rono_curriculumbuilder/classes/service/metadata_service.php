<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Metadata Service.
 *
 * Handles curriculum metadata associated with published lessons.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\service;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\repository\curriculum_repository;

/**
 * Metadata service.
 */
class metadata_service {

    /**
     * Repository.
     *
     * @var curriculum_repository
     */
    private curriculum_repository $repository;

    /**
     * Constructor.
     */
    public function __construct() {

        $this->repository = new curriculum_repository();
    }

    /**
     * Save curriculum metadata.
     *
     * @param int $lessonid
     * @param array $metadata
     * @return int
     * @throws \dml_exception
     */
    public function save(
        int $lessonid,
        array $metadata
    ): int {

        $record = new \stdClass();

        $record->lessonid = $lessonid;

        $record->build_id = $metadata['build_id'] ?? '';

        $record->lesson_uuid = $metadata['lesson_uuid'] ?? '';

        $record->topic_id = $metadata['topic_id'] ?? '';

        $record->lesson_package_id =
            $metadata['lesson_package_id'] ?? '';

        $record->subject = $metadata['subject'] ?? '';

        $record->learning_area =
            $metadata['learning_area'] ?? '';

        $record->year_level =
            $metadata['year_level'] ?? '';

        $record->curriculum_version =
            $metadata['curriculum_version'] ?? '';

        $record->curriculum_code =
            $metadata['curriculum_code'] ?? '';

        $record->parent_code =
            $metadata['parent_code'] ?? '';

        $record->lesson_number =
            $metadata['lesson_number'] ?? 0;

        $record->pathway =
            $metadata['pathway'] ?? '';

        $record->sequence_number =
            $metadata['sequence_number'] ?? 0;

        $record->strand =
            $metadata['strand'] ?? '';

        $record->sub_strand =
            $metadata['sub_strand'] ?? '';

        $record->topic =
            $metadata['topic'] ?? '';

        $record->difficulty =
            $metadata['difficulty'] ?? '';

        $record->estimated_time =
            $metadata['estimated_time'] ?? '';

        $record->content_description =
            $metadata['content_description'] ?? '';

        $record->elaboration =
            $metadata['elaboration'] ?? '';

        $record->workbook_filename =
            $metadata['workbook_filename'] ?? '';

        $record->timecreated = time();

        $record->timemodified = time();

        return $this->repository->create($record);
    }

    /**
     * Returns curriculum metadata.
     *
     * @param int $lessonid
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function get(
        int $lessonid
    ): ?\stdClass {

        return $this->repository->find_by_lesson(
            $lessonid
        );
    }

    /**
     * Updates curriculum metadata.
     *
     * @param \stdClass $record
     * @return bool
     * @throws \dml_exception
     */
    public function update(
        \stdClass $record
    ): bool {

        $record->timemodified = time();

        return $this->repository->update(
            $record
        );
    }

    /**
     * Deletes curriculum metadata.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function delete(
        int $lessonid
    ): bool {

        return $this->repository->delete_by_lesson(
            $lessonid
        );
    }

    /**
     * Determines whether metadata exists.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function exists(
        int $lessonid
    ): bool {

        return $this->repository->exists(
            $lessonid
        );
    }
}