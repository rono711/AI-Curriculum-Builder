<?php
namespace local_rono_curriculumbuilder;

defined('MOODLE_INTERNAL') || die();

/**
 * ============================================================================
 * Rono Curriculum Builder
 *
 * Plugin:
 *     local_rono_curriculumbuilder
 *
 * File:
 *     classes/publisher.php
 *
 * Version:
 *     2.0.0
 *
 * Author:
 *     Mohammad Hassan
 *
 * Purpose:
 *     High-level lesson publisher.
 *
 * Description:
 *     Coordinates lesson publishing into Moodle.
 *
 * ============================================================================
 */
class publisher {

    /**
     * Page Manager.
     *
     * @var page_manager
     */
    protected $pages;

    /**
     * Metadata Manager.
     *
     * @var metadata_manager|null
     */
    protected $metadata;

    /**
     * Constructor.
     */
    public function __construct() {

        $this->pages = new page_manager();

        if (class_exists(
            '\local_rono_curriculumbuilder\metadata_manager'
        )) {

            $this->metadata =
                new metadata_manager();

        } else {

            $this->metadata = null;

        }

    }

    /**
     * Publish lesson.
     *
     * Version 2.0
     *
     * Creates a new Moodle Page.
     *
     * Future versions:
     *
     * - Detect existing lesson
     * - Update instead of duplicate
     * - Upload resources
     * - Embed Google Slides
     * - Store metadata
     *
     * @param int $courseid
     * @param int $section
     * @param string $title
     * @param string $content
     *
     * @return array
     */
    public function publish(

        int $courseid,

        int $section,

        string $title,

        string $content

    ): array {

        //
        // Check whether the lesson already exists.
        //

        $existing = $this->pages->find_page(

            $courseid,

            $title

        );

        //
        // Future:
        // update existing page.
        //

        if ($existing) {

            $this->pages->update_page(

                $existing->id,

                $title,

                $content

            );

            $result = $this->pages->find_page(

                $courseid,

                $title

            );

            return [

                'status' => 'UPDATED',

                'pageid' => $result->id,

                'cmid' => null,

                'url' => null,

            ];

        }

        //
        // Create new page.
        //

        $result = $this->pages->create_page(

            $courseid,

            $section,

            $title,

            $content

        );

        //
        // Future:
        // Save metadata.
        //

        if ($this->metadata) {

            // Placeholder.
            // Metadata will be implemented later.

        }

        return [

            'status' => 'CREATED',

            'pageid' => $result['pageid'],

            'cmid' => $result['cmid'],

            'url' => $result['url'],

        ];

    }

}