<?php
namespace local_rono_curriculumbuilder;

defined('MOODLE_INTERNAL') || die();

/**
 * ============================================================================
 * Rono Curriculum Builder
 *
 * Plugin:
 *     local_rono_curriculumbuilder
 *
 * File:
 *     classes/metadata_manager.php
 *
 * Version:
 *     2.0.0
 *
 * Author:
 *     Mohammad Hassan
 *
 * Purpose:
 *     Manage lesson publishing metadata.
 *
 * Description:
 *     Version 2.0 provides a lightweight metadata manager.
 *     Future versions may persist metadata in a dedicated database table.
 *
 * ============================================================================
 */
class metadata_manager {

    /**
     * Build metadata.
     *
     * @param int $courseid
     * @param int $section
     * @param int $pageid
     * @param int $cmid
     * @param string $url
     *
     * @return array
     */
    public function build(

        int $courseid,

        int $section,

        int $pageid,

        int $cmid,

        string $url

    ): array {

        return [

            'courseid' => $courseid,

            'section' => $section,

            'pageid' => $pageid,

            'cmid' => $cmid,

            'url' => $url,

            'published' => true,

            'version' => '2.0.0',

            'publishedat' => time(),

        ];

    }

    /**
     * Save metadata.
     *
     * Version 2.0
     *
     * Placeholder.
     * Future versions will save metadata into a dedicated database table.
     *
     * @param array $metadata
     *
     * @return bool
     */
    public function save(
        array $metadata
    ): bool {

        return true;

    }

    /**
     * Load metadata.
     *
     * Placeholder.
     *
     * @param int $courseid
     * @param string $title
     *
     * @return array|null
     */
    public function load(

        int $courseid,

        string $title

    ) {

        return null;

    }

    /**
     * Delete metadata.
     *
     * Placeholder.
     *
     * @param int $pageid
     *
     * @return bool
     */
    public function delete(
        int $pageid
    ): bool {

        return true;

    }

    /**
     * Return plugin version.
     *
     * @return string
     */
    public function version(): string {

        return '2.0.0';

    }

}