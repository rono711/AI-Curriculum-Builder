<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publish Request Domain Model.
 *
 * Represents a complete lesson publishing request received from n8n.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\domain;

defined('MOODLE_INTERNAL') || die();

/**
 * Publish Request.
 */
class publish_request {

    /** @var array */
    private array $payload;

    /**
     * Constructor.
     *
     * @param array $payload
     */
    public function __construct(array $payload) {
        $this->payload = $payload;
    }

    /**
     * Returns the complete payload.
     *
     * @return array
     */
    public function get_payload(): array {
        return $this->payload;
    }

    /**
     * Returns the build ID.
     *
     * @return string
     */
    public function get_build_id(): string {
        return (string)($this->payload['build_id'] ?? '');
    }

    /**
     * Returns the course ID.
     *
     * @return int
     */
    public function get_course_id(): int {
        return (int)($this->payload['course_id'] ?? 0);
    }

    /**
     * Returns the section ID.
     *
     * @return int
     */
    public function get_section_id(): int {
        return (int)($this->payload['section_id'] ?? 0);
    }

    /**
     * Returns the lesson title.
     *
     * @return string
     */
    public function get_lesson_title(): string {
        return (string)($this->payload['lesson']['title'] ?? '');
    }

    /**
     * Returns the curriculum code.
     *
     * @return string
     */
    public function get_curriculum_code(): string {
        return (string)($this->payload['curriculum_code'] ?? '');
    }

    /**
     * Returns the lesson package ID.
     *
     * @return string
     */
    public function get_lesson_package_id(): string {
        return (string)($this->payload['lesson_package_id'] ?? '');
    }

    /**
     * Returns the topic ID.
     *
     * @return string
     */
    public function get_topic_id(): string {
        return (string)($this->payload['topic_id'] ?? '');
    }

    /**
     * Returns the HTML lesson content.
     *
     * @return string
     */
    public function get_html(): string {
        return (string)($this->payload['lesson']['html'] ?? '');
    }

    /**
     * Returns the Google Slides embed HTML.
     *
     * @return string
     */
    public function get_google_slides_embed(): string {
        return (string)($this->payload['slides']['embed_html'] ?? '');
    }

    /**
     * Returns lesson resources.
     *
     * @return array
     */
    public function get_resources(): array {
        return (array)($this->payload['resources'] ?? []);
    }

    /**
     * Returns quiz data.
     *
     * @return array
     */
    public function get_quiz(): array {
        return (array)($this->payload['quiz'] ?? []);
    }

    /**
     * Returns metadata.
     *
     * @return array
     */
    public function get_metadata(): array {
        return (array)($this->payload['metadata'] ?? []);
    }

    /**
     * Returns true if the payload contains a Google Slides embed.
     *
     * @return bool
     */
    public function has_google_slides(): bool {
        return !empty($this->payload['slides']['embed_html']);
    }

    /**
     * Returns true if resources exist.
     *
     * @return bool
     */
    public function has_resources(): bool {
        return !empty($this->payload['resources']);
    }

    /**
     * Returns true if quiz data exists.
     *
     * @return bool
     */
    public function has_quiz(): bool {
        return !empty($this->payload['quiz']);
    }

    /**
     * Returns payload as JSON.
     *
     * @return string
     */
    public function to_json(): string {
        return json_encode(
            $this->payload,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        );
    }

}