<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publish Result Domain Model.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\domain;

defined('MOODLE_INTERNAL') || die();

/**
 * Represents the result returned after publishing a lesson.
 */
class publish_result {

    /** @var bool */
    private bool $success = false;

    /** @var string */
    private string $message = '';

    /** @var int */
    private int $courseid = 0;

    /** @var int */
    private int $sectionid = 0;

    /** @var int */
    private int $cmid = 0;

    /** @var int */
    private int $pageid = 0;

    /** @var string */
    private string $activity_url = '';

    /** @var string */
    private string $lesson_uuid = '';

    /** @var string */
    private string $build_id = '';

    /** @var string */
    private string $publication_status = '';

    /**
     * Constructor.
     *
     * @param array $data
     */
    public function __construct(array $data = []) {

        foreach ($data as $property => $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
        }
    }

    /**
     * Returns whether the publish operation succeeded.
     *
     * @return bool
     */
    public function is_success(): bool {
        return $this->success;
    }

    /**
     * Returns the result message.
     *
     * @return string
     */
    public function get_message(): string {
        return $this->message;
    }

    /**
     * Returns the activity URL.
     *
     * @return string
     */
    public function get_activity_url(): string {
        return $this->activity_url;
    }

    /**
     * Returns the course module ID.
     *
     * @return int
     */
    public function get_cmid(): int {
        return $this->cmid;
    }

    /**
     * Returns the page ID.
     *
     * @return int
     */
    public function get_page_id(): int {
        return $this->pageid;
    }

    /**
     * Returns the lesson UUID.
     *
     * @return string
     */
    public function get_lesson_uuid(): string {
        return $this->lesson_uuid;
    }

    /**
     * Returns the build ID.
     *
     * @return string
     */
    public function get_build_id(): string {
        return $this->build_id;
    }

    /**
     * Returns the publication status.
     *
     * @return string
     */
    public function get_publication_status(): string {
        return $this->publication_status;
    }

    /**
     * Returns the object as an array.
     *
     * @return array
     */
    public function to_array(): array {

        return [
            'success' => $this->success,
            'message' => $this->message,
            'courseid' => $this->courseid,
            'sectionid' => $this->sectionid,
            'cmid' => $this->cmid,
            'pageid' => $this->pageid,
            'activity_url' => $this->activity_url,
            'lesson_uuid' => $this->lesson_uuid,
            'build_id' => $this->build_id,
            'publication_status' => $this->publication_status,
        ];
    }

    /**
     * Returns the object as JSON.
     *
     * @return string
     */
    public function to_json(): string {

        return json_encode(
            $this->to_array(),
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        );
    }
}