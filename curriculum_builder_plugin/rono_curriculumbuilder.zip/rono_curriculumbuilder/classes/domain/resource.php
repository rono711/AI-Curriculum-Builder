<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Resource Domain Model.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\domain;

defined('MOODLE_INTERNAL') || die();

/**
 * Represents a lesson asset/resource.
 */
class resource {

    /** @var int */
    private int $id = 0;

    /** @var int */
    private int $lessonid = 0;

    /** @var string */
    private string $assetuuid = '';

    /** @var string */
    private string $assettype = '';

    /** @var string */
    private string $assetname = '';

    /** @var string */
    private string $displayname = '';

    /** @var string */
    private string $filename = '';

    /** @var string */
    private string $mimetype = '';

    /** @var int */
    private int $filesize = 0;

    /** @var string */
    private string $url = '';

    /** @var string */
    private string $embedurl = '';

    /** @var string */
    private string $downloadurl = '';

    /** @var string */
    private string $status = 'available';

    /** @var int */
    private int $sortorder = 0;

    /**
     * Constructor.
     *
     * @param array $record
     */
    public function __construct(array $record = []) {

        foreach ($record as $property => $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
        }
    }

    /**
     * Returns the resource ID.
     *
     * @return int
     */
    public function get_id(): int {
        return $this->id;
    }

    /**
     * Returns the lesson ID.
     *
     * @return int
     */
    public function get_lesson_id(): int {
        return $this->lessonid;
    }

    /**
     * Returns the asset UUID.
     *
     * @return string
     */
    public function get_asset_uuid(): string {
        return $this->assetuuid;
    }

    /**
     * Returns the asset type.
     *
     * @return string
     */
    public function get_asset_type(): string {
        return $this->assettype;
    }

    /**
     * Returns the asset name.
     *
     * @return string
     */
    public function get_asset_name(): string {
        return $this->assetname;
    }

    /**
     * Returns the display name.
     *
     * @return string
     */
    public function get_display_name(): string {
        return $this->displayname;
    }

    /**
     * Returns the resource URL.
     *
     * @return string
     */
    public function get_url(): string {
        return $this->url;
    }

    /**
     * Returns the embed URL.
     *
     * @return string
     */
    public function get_embed_url(): string {
        return $this->embedurl;
    }

    /**
     * Returns the download URL.
     *
     * @return string
     */
    public function get_download_url(): string {
        return $this->downloadurl;
    }

    /**
     * Returns the asset status.
     *
     * @return string
     */
    public function get_status(): string {
        return $this->status;
    }

    /**
     * Returns the object as a Moodle record.
     *
     * @return \stdClass
     */
    public function to_record(): \stdClass {

        return (object) [
            'id' => $this->id,
            'lessonid' => $this->lessonid,
            'asset_uuid' => $this->assetuuid,
            'asset_type' => $this->assettype,
            'asset_name' => $this->assetname,
            'display_name' => $this->displayname,
            'filename' => $this->filename,
            'mime_type' => $this->mimetype,
            'file_size' => $this->filesize,
            'url' => $this->url,
            'embed_url' => $this->embedurl,
            'download_url' => $this->downloadurl,
            'asset_status' => $this->status,
            'sort_order' => $this->sortorder,
        ];
    }
}