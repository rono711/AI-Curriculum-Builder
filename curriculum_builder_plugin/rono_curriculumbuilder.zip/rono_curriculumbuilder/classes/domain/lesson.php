<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Lesson Domain Model.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\domain;

defined('MOODLE_INTERNAL') || die();

/**
 * Represents a published Moodle lesson.
 */
class lesson {

    /** @var int */
    private int $id = 0;

    /** @var string */
    private string $lessonuuid = '';

    /** @var string */
    private string $buildid = '';

    /** @var string */
    private string $lessonpackageid = '';

    /** @var string */
    private string $topicid = '';

    /** @var string */
    private string $curriculumcode = '';

    /** @var string */
    private string $lessontitle = '';

    /** @var int */
    private int $courseid = 0;

    /** @var int */
    private int $sectionid = 0;

    /** @var int */
    private int $cmid = 0;

    /** @var int */
    private int $pageid = 0;

    /** @var string */
    private string $activity_url = '';

    /** @var int */
    private int $publishversion = 1;

    /** @var string */
    private string $publicationstatus = 'draft';

    /** @var string */
    private string $payloadhash = '';

    /** @var int */
    private int $publishedat = 0;

    /** @var int */
    private int $timecreated = 0;

    /** @var int */
    private int $timemodified = 0;
    private int $createdby = 0;

    private int $modifiedby = 0;

    /**
     * Constructor.
     *
     * @param array $record
     */
    public function __construct(array $record = []) {

        foreach ($record as $property => $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
        }
    }

    /**
     * Returns the lesson ID.
     *
     * @return int
     */
    public function get_id(): int {
        return $this->id;
    }

    /**
     * Returns the lesson UUID.
     *
     * @return string
     */
    public function get_lesson_uuid(): string {
        return $this->lessonuuid;
    }

    /**
     * Returns the lesson title.
     *
     * @return string
     */
    public function get_lesson_title(): string {
        return $this->lessontitle;
    }

    /**
     * Returns the Moodle course ID.
     *
     * @return int
     */
    public function get_course_id(): int {
        return $this->courseid;
    }

    /**
     * Returns the Moodle section ID.
     *
     * @return int
     */
    public function get_section_id(): int {
        return $this->sectionid;
    }

    /**
     * Returns the course module ID.
     *
     * @return int
     */
    public function get_cmid(): int {
        return $this->cmid;
    }

    /**
     * Returns the page ID.
     *
     * @return int
     */
    public function get_page_id(): int {
        return $this->pageid;
    }

    /**
     * Returns the activity URL.
     *
     * @return string
     */
    public function get_activity_url(): string {
        return $this->activity_url;
    }

    /**
     * Returns the publication status.
     *
     * @return string
     */
    public function get_publication_status(): string {
        return $this->publicationstatus;
    }

    /**
     * Returns the publish version.
     *
     * @return int
     */
    public function get_publish_version(): int {
        return $this->publishversion;
    }

    /**
     * Returns the record as an object suitable for Moodle DML.
     *
     * @return \stdClass
     */
    public function to_record(): \stdClass {

        return (object)[
            'id' => $this->id,
            'lesson_uuid' => $this->lessonuuid,
            'build_id' => $this->buildid,
            'lesson_package_id' => $this->lessonpackageid,
            'topic_id' => $this->topicid,
            'curriculum_code' => $this->curriculumcode,
            'lesson_title' => $this->lessontitle,
            'courseid' => $this->courseid,
            'sectionid' => $this->sectionid,
            'cmid' => $this->cmid,
            'pageid' => $this->pageid,
            'activity_url' => $this->activity_url,
            'publish_version' => $this->publishversion,
            'publication_status' => $this->publicationstatus,
            'payload_hash' => $this->payloadhash,
            'published_at' => $this->publishedat,
             'createdby' => $this->createdby,
            'modifiedby' => $this->modifiedby,
            'timecreated' => $this->timecreated,
            'timemodified' => $this->timemodified,
           
        ];
    }

}