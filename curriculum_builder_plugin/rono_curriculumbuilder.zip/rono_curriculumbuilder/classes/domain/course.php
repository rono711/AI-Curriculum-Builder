<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Course Domain Model.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\domain;

defined('MOODLE_INTERNAL') || die();

/**
 * Represents a Moodle course.
 */
class course {

    /** @var int */
    private int $id = 0;

    /** @var string */
    private string $fullname = '';

    /** @var string */
    private string $shortname = '';

    /** @var int */
    private int $categoryid = 0;

    /** @var bool */
    private bool $visible = true;

    /**
     * Constructor.
     *
     * @param array $record
     */
    public function __construct(array $record = []) {

        foreach ($record as $property => $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
        }
    }

    /**
     * Returns the Moodle course ID.
     *
     * @return int
     */
    public function get_id(): int {
        return $this->id;
    }

    /**
     * Returns the course full name.
     *
     * @return string
     */
    public function get_fullname(): string {
        return $this->fullname;
    }

    /**
     * Returns the course short name.
     *
     * @return string
     */
    public function get_shortname(): string {
        return $this->shortname;
    }

    /**
     * Returns the category ID.
     *
     * @return int
     */
    public function get_category_id(): int {
        return $this->categoryid;
    }

    /**
     * Returns whether the course is visible.
     *
     * @return bool
     */
    public function is_visible(): bool {
        return $this->visible;
    }

    /**
     * Returns the object as a Moodle record.
     *
     * @return \stdClass
     */
    public function to_record(): \stdClass {

        return (object) [
            'id' => $this->id,
            'fullname' => $this->fullname,
            'shortname' => $this->shortname,
            'category' => $this->categoryid,
            'visible' => $this->visible ? 1 : 0,
        ];
    }
}