<?php
namespace local_rono_curriculumbuilder;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/mod/page/lib.php');

/**
 * ============================================================================
 * Rono Curriculum Builder
 *
 * Plugin:
 *     local_rono_curriculumbuilder
 *
 * File:
 *     classes/page_manager.php
 *
 * Version:
 *     2.0.0
 *
 * Author:
 *     Mohammad Hassan
 *
 * Purpose:
 *     Manage Moodle Page activities.
 *
 * ============================================================================
 */
class page_manager {

    /**
     * Create a Moodle Page activity.
     *
     * @param int $courseid
     * @param int $section
     * @param string $title
     * @param string $content
     *
     * @return array
     */
    public function create_page(
        int $courseid,
        int $section,
        string $title,
        string $content
    ): array {

        global $DB;

        $course = $DB->get_record(
            'course',
            [
                'id' => $courseid
            ],
            '*',
            MUST_EXIST
        );

        $module = $DB->get_record(
            'modules',
            [
                'name' => 'page'
            ],
            '*',
            MUST_EXIST
        );

        $page = new \stdClass();

        $page->course = $courseid;
        $page->name = $title;
        $page->intro = '';
        $page->introformat = FORMAT_HTML;
        $page->content = $content;
        $page->contentformat = FORMAT_HTML;
        $page->display = PAGE_DISPLAY_EMBED;
        $page->displayoptions = 'a:0:{}';
        $page->timemodified = time();

        $page->id = $DB->insert_record(
            'page',
            $page
        );

        $cm = new \stdClass();

        $cm->course = $courseid;
        $cm->module = $module->id;
        $cm->instance = $page->id;
        $cm->section = $section;
        $cm->visible = 1;
        $cm->groupmode = 0;
        $cm->groupingid = 0;
        $cm->completion = 0;

        $cmid = add_course_module(
            $cm
        );

        course_add_cm_to_section(
            $courseid,
            $cmid,
            $section
        );

        rebuild_course_cache(
            $courseid,
            true
        );

        return [

            'pageid' => $page->id,

            'cmid' => $cmid,

            'url' => (
                new \moodle_url(
                    '/mod/page/view.php',
                    [
                        'id' => $cmid
                    ]
                )
            )->out(false),

        ];

    }

    /**
     * Update a Moodle Page.
     *
     * @param int $pageid
     * @param string $title
     * @param string $content
     *
     * @return bool
     */
    public function update_page(
        int $pageid,
        string $title,
        string $content
    ): bool {

        global $DB;

        $page = $DB->get_record(
            'page',
            [
                'id' => $pageid
            ],
            '*',
            MUST_EXIST
        );

        $page->name = $title;
        $page->content = $content;
        $page->timemodified = time();

        $DB->update_record(
            'page',
            $page
        );

        rebuild_course_cache(
            $page->course,
            true
        );

        return true;

    }

    /**
     * Find a page by title.
     *
     * @param int $courseid
     * @param string $title
     *
     * @return object|null
     */
    public function find_page(
        int $courseid,
        string $title
    ) {

        global $DB;

        $sql = "
            SELECT p.*
              FROM {page} p
              JOIN {course_modules} cm
                ON cm.instance = p.id
              JOIN {modules} m
                ON m.id = cm.module
             WHERE p.course = ?
               AND p.name = ?
               AND m.name = 'page'
        ";

        return $DB->get_record_sql(
            $sql,
            [
                $courseid,
                $title
            ]
        );

    }

}