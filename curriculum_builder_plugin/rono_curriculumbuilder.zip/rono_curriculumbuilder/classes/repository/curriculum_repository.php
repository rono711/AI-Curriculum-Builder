<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Curriculum Repository.
 *
 * Handles all database operations for curriculum records.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\repository;

defined('MOODLE_INTERNAL') || die();

/**
 * Repository for curriculum records.
 */
class curriculum_repository {

    /**
     * Database table.
     */
    private const TABLE = 'local_rono_curriculum';

    /**
     * Create a curriculum record.
     *
     * @param \stdClass $record
     * @return int
     * @throws \dml_exception
     */
    public function create(\stdClass $record): int {

        global $DB;

        return $DB->insert_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Update a curriculum record.
     *
     * @param \stdClass $record
     * @return bool
     * @throws \dml_exception
     */
    public function update(\stdClass $record): bool {

        global $DB;

        return $DB->update_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Delete curriculum by lesson.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function delete_by_lesson(int $lessonid): bool {

        global $DB;

        return $DB->delete_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }

    /**
     * Find curriculum by lesson.
     *
     * @param int $lessonid
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_lesson(int $lessonid): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );

        return $record ?: null;
    }

    /**
     * Find curriculum by curriculum code.
     *
     * @param string $curriculumcode
     * @return array
     * @throws \dml_exception
     */
    public function find_by_curriculum_code(string $curriculumcode): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'curriculum_code' => $curriculumcode
            ],
            'lesson_number ASC'
        );
    }

    /**
     * Find curriculum by subject and year.
     *
     * @param string $subject
     * @param string $yearlevel
     * @return array
     * @throws \dml_exception
     */
    public function find_by_subject_year(
        string $subject,
        string $yearlevel
    ): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'subject' => $subject,
                'year_level' => $yearlevel
            ],
            'lesson_number ASC'
        );
    }

    /**
     * Curriculum exists.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function exists(int $lessonid): bool {

        global $DB;

        return $DB->record_exists(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }

    /**
     * Count curriculum records.
     *
     * @return int
     * @throws \dml_exception
     */
    public function count(): int {

        global $DB;

        return $DB->count_records(
            self::TABLE
        );
    }
}