<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Lesson Repository.
 *
 * Handles all database operations for published lessons.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\repository;

defined('MOODLE_INTERNAL') || die();

use local_rono_curriculumbuilder\domain\lesson;

/**
 * Repository for lesson records.
 */
class lesson_repository {

    /**
     * Database table.
     */
    private const TABLE = 'local_rono_lessons';

    /**
     * Create a lesson.
     *
     * @param lesson $lesson
     * @return int
     * @throws \dml_exception
     */
    public function create(lesson $lesson): int {

        global $DB;

        return $DB->insert_record(
            self::TABLE,
            $lesson->to_record()
        );
    }

    /**
     * Update a lesson.
     *
     * @param lesson $lesson
     * @return bool
     * @throws \dml_exception
     */
    public function update(lesson $lesson): bool {

        global $DB;

        return $DB->update_record(
            self::TABLE,
            $lesson->to_record()
        );
    }

    /**
     * Delete a lesson.
     *
     * @param int $id
     * @return bool
     * @throws \dml_exception
     */
    public function delete(int $id): bool {

        global $DB;

        return $DB->delete_records(
            self::TABLE,
            [
                'id' => $id
            ]
        );
    }

    /**
     * Find by ID.
     *
     * @param int $id
     * @return lesson|null
     * @throws \dml_exception
     */
    public function find_by_id(int $id): ?lesson {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'id' => $id
            ]
        );

        if (!$record) {
            return null;
        }

        return new lesson((array)$record);
    }

    /**
     * Find by Lesson UUID.
     *
     * @param string $uuid
     * @return lesson|null
     * @throws \dml_exception
     */
    public function find_by_uuid(string $uuid): ?lesson {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'lesson_uuid' => $uuid
            ]
        );

        if (!$record) {
            return null;
        }

        return new lesson((array)$record);
    }

    /**
     * Find by Lesson Package ID.
     *
     * @param string $packageid
     * @return lesson|null
     * @throws \dml_exception
     */
    public function find_by_package(string $packageid): ?lesson {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'lesson_package_id' => $packageid
            ]
        );

        if (!$record) {
            return null;
        }

        return new lesson((array)$record);
    }

    /**
     * Find by Course.
     *
     * @param int $courseid
     * @return lesson[]
     * @throws \dml_exception
     */
    public function find_by_course(int $courseid): array {

        global $DB;

        $records = $DB->get_records(
            self::TABLE,
            [
                'courseid' => $courseid
            ],
            'lesson_title ASC'
        );

        $lessons = [];

        foreach ($records as $record) {
            $lessons[] = new lesson((array)$record);
        }

        return $lessons;
    }

    /**
     * Find all lessons.
     *
     * @return lesson[]
     * @throws \dml_exception
     */
    public function find_all(): array {

        global $DB;

        $records = $DB->get_records(
            self::TABLE,
            null,
            'lesson_title ASC'
        );

        $lessons = [];

        foreach ($records as $record) {
            $lessons[] = new lesson((array)$record);
        }

        return $lessons;
    }

    /**
     * Lesson exists.
     *
     * @param string $uuid
     * @return bool
     * @throws \dml_exception
     */
    public function exists(string $uuid): bool {

        global $DB;

        return $DB->record_exists(
            self::TABLE,
            [
                'lesson_uuid' => $uuid
            ]
        );
    }

    /**
     * Count published lessons.
     *
     * @return int
     * @throws \dml_exception
     */
    public function count(): int {

        global $DB;

        return $DB->count_records(
            self::TABLE
        );
    }
}