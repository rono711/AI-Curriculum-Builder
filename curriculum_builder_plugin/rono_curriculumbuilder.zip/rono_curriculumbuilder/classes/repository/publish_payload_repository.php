<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publish Payload Repository.
 *
 * Handles immutable publish payload snapshots.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\repository;

defined('MOODLE_INTERNAL') || die();

/**
 * Repository for publish payload snapshots.
 */
class publish_payload_repository {

    /**
     * Database table.
     */
    private const TABLE = 'local_rono_publish_payload';

    /**
     * Create a payload snapshot.
     *
     * @param \stdClass $record
     * @return int
     * @throws \dml_exception
     */
    public function create(\stdClass $record): int {

        global $DB;

        return $DB->insert_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Update a payload snapshot.
     *
     * @param \stdClass $record
     * @return bool
     * @throws \dml_exception
     */
    public function update(\stdClass $record): bool {

        global $DB;

        return $DB->update_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Delete all payload snapshots for a lesson.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function delete_by_lesson(int $lessonid): bool {

        global $DB;

        return $DB->delete_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }

    /**
     * Find payload by ID.
     *
     * @param int $id
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_id(int $id): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'id' => $id
            ]
        );

        return $record ?: null;
    }

    /**
     * Returns the latest payload for a lesson.
     *
     * @param int $lessonid
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_latest_by_lesson(int $lessonid): ?\stdClass {

        global $DB;

        $records = $DB->get_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ],
            'publish_version DESC',
            '*',
            0,
            1
        );

        if (empty($records)) {
            return null;
        }

        return reset($records);
    }

    /**
     * Find payload by hash.
     *
     * @param string $hash
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_hash(string $hash): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'payload_hash' => $hash
            ]
        );

        return $record ?: null;
    }

    /**
     * Returns all payload versions for a lesson.
     *
     * @param int $lessonid
     * @return array
     * @throws \dml_exception
     */
    public function find_versions(int $lessonid): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ],
            'publish_version DESC'
        );
    }

    /**
     * Returns the latest publish version.
     *
     * @param int $lessonid
     * @return int
     * @throws \dml_exception
     */
    public function get_latest_version(int $lessonid): int {

        $record = $this->find_latest_by_lesson($lessonid);

        if (!$record) {
            return 0;
        }

        return (int)$record->publish_version;
    }

    /**
     * Payload exists.
     *
     * @param string $hash
     * @return bool
     * @throws \dml_exception
     */
    public function exists(string $hash): bool {

        global $DB;

        return $DB->record_exists(
            self::TABLE,
            [
                'payload_hash' => $hash
            ]
        );
    }

    /**
     * Count payload snapshots.
     *
     * @return int
     * @throws \dml_exception
     */
    public function count(): int {

        global $DB;

        return $DB->count_records(
            self::TABLE
        );
    }
}