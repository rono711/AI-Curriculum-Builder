<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Publish History Repository.
 *
 * Handles all database operations for lesson publish history.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\repository;

defined('MOODLE_INTERNAL') || die();

/**
 * Repository for publish history records.
 */
class publish_history_repository {

    /**
     * Database table.
     */
    private const TABLE = 'local_rono_publish_history';

    /**
     * Create a history record.
     *
     * @param \stdClass $record
     * @return int
     * @throws \dml_exception
     */
    public function create(\stdClass $record): int {

        global $DB;

        return $DB->insert_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Find a history record by ID.
     *
     * @param int $id
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_id(int $id): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'id' => $id
            ]
        );

        return $record ?: null;
    }

    /**
     * Returns all history for a lesson.
     *
     * @param int $lessonid
     * @return array
     * @throws \dml_exception
     */
    public function find_by_lesson(int $lessonid): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ],
            'timecreated DESC'
        );
    }

    /**
     * Returns all history for a build.
     *
     * @param string $buildid
     * @return array
     * @throws \dml_exception
     */
    public function find_by_build(string $buildid): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'build_id' => $buildid
            ],
            'timecreated DESC'
        );
    }

    /**
     * Returns all history for an event type.
     *
     * @param string $eventtype
     * @return array
     * @throws \dml_exception
     */
    public function find_by_event(string $eventtype): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'event_type' => $eventtype
            ],
            'timecreated DESC'
        );
    }

    /**
     * Delete all history for a lesson.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function delete_by_lesson(int $lessonid): bool {

        global $DB;

        return $DB->delete_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }

    /**
     * Count history records.
     *
     * @param int|null $lessonid
     * @return int
     * @throws \dml_exception
     */
    public function count(?int $lessonid = null): int {

        global $DB;

        if ($lessonid === null) {
            return $DB->count_records(self::TABLE);
        }

        return $DB->count_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }
}