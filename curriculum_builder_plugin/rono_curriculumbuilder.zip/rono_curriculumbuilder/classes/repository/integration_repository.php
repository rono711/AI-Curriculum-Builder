<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Integration Repository.
 *
 * Handles all database operations for lesson integrations.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_rono_curriculumbuilder\repository;

defined('MOODLE_INTERNAL') || die();

/**
 * Repository for external integrations.
 */
class integration_repository {

    /**
     * Database table.
     */
    private const TABLE = 'local_rono_integrations';

    /**
     * Create an integration.
     *
     * @param \stdClass $record
     * @return int
     * @throws \dml_exception
     */
    public function create(\stdClass $record): int {

        global $DB;

        return $DB->insert_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Update an integration.
     *
     * @param \stdClass $record
     * @return bool
     * @throws \dml_exception
     */
    public function update(\stdClass $record): bool {

        global $DB;

        return $DB->update_record(
            self::TABLE,
            $record
        );
    }

    /**
     * Delete all integrations for a lesson.
     *
     * @param int $lessonid
     * @return bool
     * @throws \dml_exception
     */
    public function delete_by_lesson(int $lessonid): bool {

        global $DB;

        return $DB->delete_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }

    /**
     * Find an integration by ID.
     *
     * @param int $id
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_id(int $id): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'id' => $id
            ]
        );

        return $record ?: null;
    }

    /**
     * Find integrations for a lesson.
     *
     * @param int $lessonid
     * @return array
     * @throws \dml_exception
     */
    public function find_by_lesson(int $lessonid): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ],
            'integration_type ASC'
        );
    }

    /**
     * Find an integration by type.
     *
     * @param int $lessonid
     * @param string $type
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_type(
        int $lessonid,
        string $type
    ): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'lessonid' => $lessonid,
                'integration_type' => $type
            ]
        );

        return $record ?: null;
    }

    /**
     * Find an integration by external ID.
     *
     * @param string $externalid
     * @return \stdClass|null
     * @throws \dml_exception
     */
    public function find_by_external_id(string $externalid): ?\stdClass {

        global $DB;

        $record = $DB->get_record(
            self::TABLE,
            [
                'external_id' => $externalid
            ]
        );

        return $record ?: null;
    }

    /**
     * Returns all failed integrations.
     *
     * @return array
     * @throws \dml_exception
     */
    public function find_failed(): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'sync_status' => 'failed'
            ],
            'last_attempted_sync DESC'
        );
    }

    /**
     * Returns all pending integrations.
     *
     * @return array
     * @throws \dml_exception
     */
    public function find_pending(): array {

        global $DB;

        return $DB->get_records(
            self::TABLE,
            [
                'sync_status' => 'pending'
            ],
            'timecreated ASC'
        );
    }

    /**
     * Integration exists.
     *
     * @param int $lessonid
     * @param string $type
     * @return bool
     * @throws \dml_exception
     */
    public function exists(
        int $lessonid,
        string $type
    ): bool {

        global $DB;

        return $DB->record_exists(
            self::TABLE,
            [
                'lessonid' => $lessonid,
                'integration_type' => $type
            ]
        );
    }

    /**
     * Count integrations.
     *
     * @param int|null $lessonid
     * @return int
     * @throws \dml_exception
     */
    public function count(?int $lessonid = null): int {

        global $DB;

        if ($lessonid === null) {
            return $DB->count_records(self::TABLE);
        }

        return $DB->count_records(
            self::TABLE,
            [
                'lessonid' => $lessonid
            ]
        );
    }
}