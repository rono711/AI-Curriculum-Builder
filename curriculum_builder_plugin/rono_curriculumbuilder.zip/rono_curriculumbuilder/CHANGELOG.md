# Changelog

All notable changes to the **Rono Curriculum Builder** plugin are documented in this file.

---

# Version 2.0.0

Release Date

```
2026-07-04
```

## Initial Production Framework

### Plugin

- Initial Moodle 5.2 local plugin
- Production plugin structure
- Stable namespace
- Stable component

### Web Services

Implemented

```
local_rono_curriculumbuilder_ping
```

```
local_rono_curriculumbuilder_health
```

```
local_rono_curriculumbuilder_create_page
```

```
local_rono_curriculumbuilder_update_page
```

```
local_rono_curriculumbuilder_publish_lesson
```

### Core Classes

Added

```
page_manager.php
```

```
publisher.php
```

```
metadata_manager.php
```

### Security

Added

- Publish capability
- View capability
- Context validation
- Capability validation

### Settings

Added

- Enable Plugin
- Default Section

---

# Planned Version 2.1

## Publishing

- Google Slides embedding
- Google Drive integration
- Automatic Page updates
- Duplicate lesson detection

---

# Planned Version 2.2

## Resources

- Teacher Guide upload
- Student Worksheet upload
- Quiz upload
- Resource management

---

# Planned Version 2.3

## Metadata

- Publishing history
- Lesson versioning
- Activity tracking
- Rollback support

---

# Planned Version 2.4

## Monitoring

- Health diagnostics
- Publishing statistics
- Error reporting
- Logging

---

# Planned Version 3.0

## Complete Automation

```
Workbook

?

Prompt Generator

?

Gamma

?

Google Drive

?

Google Slides

?

HTML Builder

?

Publisher

?

Rono Curriculum Builder Plugin

?

Moodle

?

Teacher Notification
```

---

# Support

AI Curriculum Builder Platform

Author

Mohammad Hassan