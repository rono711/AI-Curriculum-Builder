<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin dashboard.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();

$context = context_system::instance();

require_capability(
    'local/rono_curriculumbuilder:manage',
    $context
);

$PAGE->set_context($context);

$PAGE->set_url(
    new moodle_url('/local/rono_curriculumbuilder/index.php')
);

$PAGE->set_pagelayout('admin');

$PAGE->set_title(
    get_string('pluginname', 'local_rono_curriculumbuilder')
);

$PAGE->set_heading(
    get_string('pluginname', 'local_rono_curriculumbuilder')
);

echo $OUTPUT->header();

echo $OUTPUT->heading(
    get_string('pluginname', 'local_rono_curriculumbuilder')
);

echo html_writer::tag(
    'p',
    'Welcome to the Rono Curriculum Builder Moodle Publishing Engine.'
);

$table = new html_table();

$table->head = [
    'Component',
    'Status'
];

$table->data = [

    [
        'Plugin',
        local_rono_curriculumbuilder_is_enabled()
            ? 'Enabled'
            : 'Disabled'
    ],

    [
        'Version',
        local_rono_curriculumbuilder_get_version()
    ],

    [
        'Logging',
        local_rono_curriculumbuilder_logging_enabled()
            ? 'Enabled'
            : 'Disabled'
    ],

    [
        'Debug Mode',
        local_rono_curriculumbuilder_debug_enabled()
            ? 'Enabled'
            : 'Disabled'
    ],

    [
        'External Service',
        local_rono_curriculumbuilder_service_name()
    ],

    [
        'Service Short Name',
        local_rono_curriculumbuilder_service_shortname()
    ]

];

echo html_writer::table($table);

echo $OUTPUT->heading(
    'Current Development Status',
    3
);

$status = new html_table();

$status->head = [
    'Module',
    'Status'
];

$status->data = [

    [
        'Database',
        'Completed'
    ],

    [
        'Plugin Configuration',
        'Completed'
    ],

    [
        'External Services',
        'Completed'
    ],

    [
        'Publishing Service',
        'Pending'
    ],

    [
        'Lesson Publisher',
        'Pending'
    ],

    [
        'Quiz Publisher',
        'Pending'
    ],

    [
        'Resource Publisher',
        'Pending'
    ],

    [
        'AI Services',
        'Future'
    ]

];

echo html_writer::table($status);

echo $OUTPUT->footer();