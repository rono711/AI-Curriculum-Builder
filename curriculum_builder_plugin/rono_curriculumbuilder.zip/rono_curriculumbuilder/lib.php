<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Library functions for the Rono Curriculum Builder plugin.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Extends the site navigation.
 *
 * @param global_navigation $navigation
 */
function local_rono_curriculumbuilder_extend_navigation(global_navigation $navigation): void {

    if (!has_capability('local/rono_curriculumbuilder:manage', context_system::instance())) {
        return;
    }

    $navigation->add(
        get_string('pluginname', 'local_rono_curriculumbuilder'),
        new moodle_url('/local/rono_curriculumbuilder/index.php'),
        navigation_node::TYPE_CUSTOM,
        null,
        'local_rono_curriculumbuilder'
    );
}

/**
 * Extends the administration navigation.
 *
 * @param settings_navigation $settingsnav
 * @param context $context
 */
function local_rono_curriculumbuilder_extend_settings_navigation(
    settings_navigation $settingsnav,
    context $context
): void {

    if (!has_capability('local/rono_curriculumbuilder:manage', $context)) {
        return;
    }

    $url = new moodle_url('/local/rono_curriculumbuilder/index.php');

    $node = navigation_node::create(
        get_string('pluginname', 'local_rono_curriculumbuilder'),
        $url,
        navigation_node::TYPE_SETTING,
        null,
        'local_rono_curriculumbuilder'
    );

    $settingsnav->add_node($node);
}

/**
 * Returns the plugin version.
 *
 * @return string
 */
function local_rono_curriculumbuilder_get_version(): string {

    global $CFG;

    require_once($CFG->dirroot . '/local/rono_curriculumbuilder/version.php');

    return $plugin->release;
}

/**
 * Determines whether the plugin is enabled.
 *
 * @return bool
 */
function local_rono_curriculumbuilder_is_enabled(): bool {

    return (bool)get_config(
        'local_rono_curriculumbuilder',
        'enableplugin'
    );
}

/**
 * Returns whether debug mode is enabled.
 *
 * @return bool
 */
function local_rono_curriculumbuilder_debug_enabled(): bool {

    return (bool)get_config(
        'local_rono_curriculumbuilder',
        'debugmode'
    );
}

/**
 * Returns whether detailed logging is enabled.
 *
 * @return bool
 */
function local_rono_curriculumbuilder_logging_enabled(): bool {

    return (bool)get_config(
        'local_rono_curriculumbuilder',
        'enablelogging'
    );
}

/**
 * Require the plugin to be enabled.
 *
 * @throws moodle_exception
 */
function local_rono_curriculumbuilder_require_enabled(): void {

    if (!local_rono_curriculumbuilder_is_enabled()) {
        throw new moodle_exception(
            'serviceunavailable',
            'local_rono_curriculumbuilder'
        );
    }
}

/**
 * Returns the configured external service short name.
 *
 * @return string
 */
function local_rono_curriculumbuilder_service_shortname(): string {

    return get_config(
        'local_rono_curriculumbuilder',
        'serviceshortname'
    ) ?: 'local_rono_Curriculum_Builder';
}

/**
 * Returns the configured external service name.
 *
 * @return string
 */
function local_rono_curriculumbuilder_service_name(): string {

    return get_config(
        'local_rono_curriculumbuilder',
        'servicename'
    ) ?: 'Rono Curriculum Builder';
}