<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin settings.
 *
 * @package     local_rono_curriculumbuilder
 * @copyright   2026 Mohammad Hassan
 * @author      Mohammad Hassan
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {

    $settings = new admin_settingpage(
        'local_rono_curriculumbuilder',
        get_string('pluginname', 'local_rono_curriculumbuilder')
    );

    /*
     * -------------------------------------------------------------------------
     * General
     * -------------------------------------------------------------------------
     */

    $settings->add(new admin_setting_heading(
        'local_rono_curriculumbuilder/generalheading',
        get_string('generalsettings', 'local_rono_curriculumbuilder'),
        ''
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_rono_curriculumbuilder/enableplugin',
        get_string('enableplugin', 'local_rono_curriculumbuilder'),
        get_string('enableplugin_desc', 'local_rono_curriculumbuilder'),
        1
    ));

    /*
     * -------------------------------------------------------------------------
     * API
     * -------------------------------------------------------------------------
     */

    $settings->add(new admin_setting_heading(
        'local_rono_curriculumbuilder/apiheading',
        get_string('apisettings', 'local_rono_curriculumbuilder'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_rono_curriculumbuilder/servicename',
        get_string('servicename', 'local_rono_curriculumbuilder'),
        'External Service Name',
        'Rono Curriculum Builder',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configtext(
        'local_rono_curriculumbuilder/serviceshortname',
        get_string('serviceshortname', 'local_rono_curriculumbuilder'),
        'External Service Short Name',
        'local_rono_Curriculum_Builder',
        PARAM_ALPHANUMEXT
    ));

    /*
     * -------------------------------------------------------------------------
     * Publishing
     * -------------------------------------------------------------------------
     */

    $settings->add(new admin_setting_heading(
        'local_rono_curriculumbuilder/publishheading',
        get_string('publishsettings', 'local_rono_curriculumbuilder'),
        ''
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_rono_curriculumbuilder/autocreatesections',
        'Automatically create course sections',
        'Create the requested section if it does not already exist.',
        1
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_rono_curriculumbuilder/overwritepages',
        'Overwrite existing lesson pages',
        'Allow republishing to replace an existing lesson page.',
        1
    ));

    /*
     * -------------------------------------------------------------------------
     * Logging
     * -------------------------------------------------------------------------
     */

    $settings->add(new admin_setting_heading(
        'local_rono_curriculumbuilder/logheading',
        get_string('loggingsettings', 'local_rono_curriculumbuilder'),
        ''
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_rono_curriculumbuilder/enablelogging',
        get_string('enablelogging', 'local_rono_curriculumbuilder'),
        get_string('enablelogging_desc', 'local_rono_curriculumbuilder'),
        1
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_rono_curriculumbuilder/debugmode',
        get_string('debugmode', 'local_rono_curriculumbuilder'),
        get_string('debugmode_desc', 'local_rono_curriculumbuilder'),
        0
    ));

    /*
     * -------------------------------------------------------------------------
     * Security
     * -------------------------------------------------------------------------
     */

    $settings->add(new admin_setting_heading(
        'local_rono_curriculumbuilder/securityheading',
        get_string('securitysettings', 'local_rono_curriculumbuilder'),
        ''
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_rono_curriculumbuilder/restrictusers',
        'Restrict to authorised users',
        'When enabled, only authorised users can access the external service.',
        0
    ));

    /*
     * -------------------------------------------------------------------------
     * AI (Future)
     * -------------------------------------------------------------------------
     */

    $settings->add(new admin_setting_heading(
        'local_rono_curriculumbuilder/aiheading',
        'AI Providers',
        'Reserved for future AI provider configuration.'
    ));

    $ADMIN->add(
        'localplugins',
        $settings
    );
}